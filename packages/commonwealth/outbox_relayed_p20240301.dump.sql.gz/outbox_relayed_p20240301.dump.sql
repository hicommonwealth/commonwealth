--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: outbox_relayed_p20240301; Type: TABLE; Schema: public; Owner: commonwealth
--

CREATE TABLE public.outbox_relayed_p20240301 (
    event_id bigint NOT NULL,
    event_name text NOT NULL,
    event_payload jsonb NOT NULL,
    relayed boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL
);


ALTER TABLE public.outbox_relayed_p20240301 OWNER TO commonwealth;

--
-- Name: outbox_relayed_p20240301; Type: TABLE ATTACH; Schema: public; Owner: commonwealth
--

ALTER TABLE ONLY public.outbox_relayed ATTACH PARTITION public.outbox_relayed_p20240301 FOR VALUES FROM ('2024-03-01 00:00:00+00') TO ('2024-04-01 00:00:00+00');


--
-- Data for Name: outbox_relayed_p20240301; Type: TABLE DATA; Schema: public; Owner: commonwealth
--

COPY public.outbox_relayed_p20240301 (event_id, event_name, event_payload, relayed, created_at, updated_at) FROM stdin;
\.


--
-- PostgreSQL database dump complete
--

